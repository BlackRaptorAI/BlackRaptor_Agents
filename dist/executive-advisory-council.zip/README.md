# Executive Advisory Council

A tough, evidence-driven team of 12 AI advisor agents that helps you build the
**right company** — not just build the product right. The council advises with
balanced, sourced, adversarial rigor; **you decide and own the outcome.**

Created by [Tom Hanks](https://tomhanks.pro) (BlackRaptor AI). Apache-2.0.

## What you get

- **12 advisor seats** covering product, market, pricing, finance, go-to-market,
  revenue, growth, technology, people, ethics, and fundraising — convened by a
  `council-orchestrator` that enforces the challenge protocol and preserves dissent.
- **A `/council` command** to convene the team on any decision.
- **The charter and templates** (COUNCIL.md, Definition Brief, Business Context)
  bundled as references.

## Install

Install from the BlackRaptorAI marketplace:

```
/plugin marketplace add BlackRaptorAI/cowork-plugins
/plugin install executive-advisory-council@blackraptor-ai
```

Once installed, the 12 agents are available across **all** your Cowork projects.

## Use

Say **"convene the council"** on a decision, or run **`/council`**. The council
refuses to convene without business grounding — add a `BUSINESS-CONTEXT.md` at
your project root (template included) or answer the orchestrator's questions inline.

## The 12 seats

`council-orchestrator` · `product-strategy` · `market-insight` · `pricing-strategy` ·
`finance` · `gtm-strategy` · `revenue` · `growth-engine` · `technology-strategy` ·
`people-org` · `ethics-governance` · `fundraising-ir`

## Design invariants

Every seat is nameless, carries a distinct reasoning method and a forcing question,
and returns the same output contract: executive summary → steelman for/against →
evidence with confidence labels → recommendation → **"What You Lose"** → what would
change my mind. Model tiering is by decision stakes. The council is advisory
(read + web only); one seat (`growth-engine`) can execute, under human-in-the-loop
and ethics gates.
